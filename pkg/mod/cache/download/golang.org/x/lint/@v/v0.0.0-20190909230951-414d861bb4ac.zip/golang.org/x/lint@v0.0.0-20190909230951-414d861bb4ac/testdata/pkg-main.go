// Test of package comment for package main.
// OK

// This binary does something awesome.
package main
